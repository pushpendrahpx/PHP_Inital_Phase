<?php
if($_POST && isset($_POST['name']) && isset($_POST['phone']) && isset($_POST['department'])){

	$name = $_POST['name'];
	$phone = $_POST['phone'];
	$department = $_POST['department'];

	$name = addcslashes($name,"'");
	$name = addcslashes($name,'"');

	$phone = addcslashes($phone,"'");
	$phone = addcslashes($phone,'"');

	if((strlen($name) >= 3) && (strlen($phone) == 10)){
		$mysqli = mysqli_connect("127.0.0.1","root","","t_users");
		if($mysqli){
			echo "Done";
		}

		$query = "INSERT INTO t_users (name,phone,branch) VALUES ('$name','$phone','$department') ";
		$fire = $mysqli->query($query);
		if($fire){
			header("location:success.php");


		}else{
			echo "error - 3".$query;
			print_r($fire);
		}

	}else{
		echo "error - 2";
	}

}else{
	echo "error - 1";
}